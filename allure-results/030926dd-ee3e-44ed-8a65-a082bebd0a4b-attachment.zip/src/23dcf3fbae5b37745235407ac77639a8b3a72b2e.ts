import { test as base } from '@playwright/test';
import { UsersPage } from '../pages/UsersPage.js';

// Definimos quais fixtures customizadas vamos injetar nos testes
type MyFixtures = {
    usersPage: UsersPage;
};

export const test = base.extend<MyFixtures>({
    usersPage: async ({ page }, use) => {
        // Inicializa a Page Object
        const usersPage = new UsersPage(page);

        // Executa a navegação padrão (com tratamento de cookies) antes de entregar para o teste
        await usersPage.goto();

        // Disponibiliza a fixture para o teste rodar
        await use(usersPage);
    },
});

export { expect } from '@playwright/test';